TRX WINGO V2 - WEBSITE ONLY

Included:
- Purple premium responsive dashboard
- Password login (no Telegram bot, no key generator)
- Live history fetched server-side from configured API
- BIG/SMALL frequency and trend chart (Chart.js CDN)
- Hybrid descriptive analysis: 20/50 draw frequency, transition frequency, streak context
- Walk-forward historical backtest; WAIT signals are skipped
- Live prediction history with exact-issue WIN/LOSE/PENDING tracking
- Optional browser sound notification on a newly observed issue

Android/Pydroid setup:
1. Extract the trx_wingo_vip folder.
2. Install: pip install flask requests python-dotenv
3. In the project folder, create .env using .env.example as a guide.
4. Set LOGIN_PASSWORD and a long random SECRET_KEY.
5. Run: python app.py
6. Open http://127.0.0.1:8080

Note:
- Chart.js is loaded from jsDelivr CDN, so the chart needs internet access.
- API availability/CORS is handled server-side; API format changes may require parser updates.
- The analysis is descriptive and experimental, not a reliable prediction of random lottery outcomes.
- Backtest results are historical only and can overfit; do not interpret them as future win probability.
- Change the shared password and SECRET_KEY before exposing the site publicly.
